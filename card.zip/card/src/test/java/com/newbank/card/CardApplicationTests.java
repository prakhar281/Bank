package com.newbank.card;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardApplicationTests {

	@Test
	void contextLoads() {
	}

}
